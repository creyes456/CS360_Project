package com.example.cs360_project_two;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DataGridActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private DatabaseHelper databaseHelper;
    private LinearLayout eventsContainer;
    private Button addButton;
    private CheckBox smsCheckBox;
    private String currentUsername;
    private int currentUserId;
    private boolean smsPermissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Get username from intent or SharedPreferences
        currentUsername = getIntent().getStringExtra("USERNAME");
        if (currentUsername == null) {
            currentUsername = getUsernameFromSession();
        }
        currentUserId = databaseHelper.getUserId(currentUsername);

        // Initialize UI components
        initializeViews();

        // Load and display events
        loadEvents();

        // Set up button listeners
        setupListeners();

        // Check SMS permission status
        checkSmsPermission();

        // SMS notifications checkbox
        CheckBox smsCheckBox = findViewById(R.id.checkBox);
        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);

        // Load saved SMS preference (default false)
        boolean smsEnabled = prefs.getBoolean("smsEnabled", false);
        smsCheckBox.setChecked(smsEnabled);

        // Toggle SMS notifications
        smsCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("smsEnabled", isChecked).apply();

            if (isChecked) {
                enableSmsNotifications();
            } else {
                disableSmsNotifications();
            }
        });
    }

    //Initialize views
    private void initializeViews() {
        addButton = findViewById(R.id.addBtn);
        smsCheckBox = findViewById(R.id.checkBox);

        // Get the ScrollView and find the LinearLayout inside it
        ScrollView scrollView = findViewById(R.id.eventsScrollView);
        if (scrollView != null) {
            eventsContainer = (LinearLayout) scrollView.getChildAt(0);
        }
    }

    //Set up listeners
    private void setupListeners() {
        // Add Event button
        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataGridActivity.this, EditActivity.class);
            intent.putExtra("USER_ID", currentUserId);
            intent.putExtra("MODE", "ADD");
            startActivity(intent);
        });

        // SMS Notifications checkbox
        smsCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Request SMS permission
                requestSmsPermission();
            } else {
                // Disable SMS notifications
                saveSmsPreference(false);
                Toast.makeText(this, "SMS notifications disabled",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

   //Load all events
    private void loadEvents() {
        // Clear existing views except the header
        if (eventsContainer != null) {
            eventsContainer.removeAllViews();
        }

        // Get all events for current user
        List<Event> events = databaseHelper.getAllEvents(currentUserId);

        if (events.isEmpty()) {
            // Display message if no events exist
            TextView noEventsText = new TextView(this);
            noEventsText.setText("No events yet. Click 'Add Event' to create one.");
            noEventsText.setPadding(16, 16, 16, 16);
            noEventsText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            eventsContainer.addView(noEventsText);
        } else {
            // Create a row for each event
            for (Event event : events) {
                createEventRow(event);
            }

            // Check for upcoming events and send SMS if enabled
            checkUpcomingEvents(events);
        }
    }
    //Check row and create event row
    private void createEventRow(Event event) {
        // Create horizontal LinearLayout for the row
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(8, 8, 8, 8);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        row.setLayoutParams(rowParams);

        // Event name TextView
        TextView eventNameView = new TextView(this);
        eventNameView.setText(event.getEventName());
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f
        );
        eventNameView.setLayoutParams(nameParams);

        // Event date TextView
        TextView eventDateView = new TextView(this);
        eventDateView.setText(event.getEventDate());
        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
        );
        eventDateView.setLayoutParams(dateParams);

        // Edit button
        Button editButton = new Button(this);
        editButton.setText("Edit");
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
        );
        editButton.setLayoutParams(buttonParams);
        editButton.setOnClickListener(v -> openEditActivity(event));

        // Delete button
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setLayoutParams(buttonParams);
        deleteButton.setOnClickListener(v -> confirmDelete(event));

        // Add all views to the row
        row.addView(eventNameView);
        row.addView(eventDateView);
        row.addView(editButton);
        row.addView(deleteButton);

        // Add row to container
        eventsContainer.addView(row);
    }

    //Open edit activity
    private void openEditActivity(Event event) {
        Intent intent = new Intent(DataGridActivity.this, EditActivity.class);
        intent.putExtra("EVENT_ID", event.getEventId());
        intent.putExtra("EVENT_NAME", event.getEventName());
        intent.putExtra("EVENT_DATE", event.getEventDate());
        intent.putExtra("USER_ID", currentUserId);
        intent.putExtra("MODE", "EDIT");
        startActivity(intent);
    }

    //Confirm delete event
    private void confirmDelete(Event event) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage("Are you sure you want to delete '" + event.getEventName() + "'?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (databaseHelper.deleteEvent(event.getEventId())) {
                        Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
                        loadEvents(); // Refresh the grid
                    } else {
                        Toast.makeText(this, "Failed to delete event",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    //Check upcoming events
    private void checkUpcomingEvents(List<Event> events) {
        if (!getSmsPreference() || !smsPermissionGranted) {
            return; // SMS not enabled or permission not granted
        }

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        Calendar today = Calendar.getInstance();
        Calendar eventCal = Calendar.getInstance();

        for (Event event : events) {
            try {
                Date eventDate = sdf.parse(event.getEventDate());
                if (eventDate != null) {
                    eventCal.setTime(eventDate);

                    // Calculate days until event
                    long diff = eventCal.getTimeInMillis() - today.getTimeInMillis();
                    long daysUntil = diff / (1000 * 60 * 60 * 24);

                    // Send SMS if event is within 3 days
                    if (daysUntil >= 0 && daysUntil <= 3) {
                        sendSmsNotification(event, daysUntil);
                    }
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }

    //Send SMS
    private void sendSmsNotification(Event event, long daysUntil) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message;

            if (daysUntil == 0) {
                message = "Reminder: '" + event.getEventName() + "' is TODAY!";
            } else if (daysUntil == 1) {
                message = "Reminder: '" + event.getEventName() + "' is TOMORROW!";
            } else {
                message = "Reminder: '" + event.getEventName() + "' is in " +
                        daysUntil + " days.";
            }

            smsManager.sendTextMessage("5554", null, message, null, null);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to send SMS notification",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // ==================== SMS PERMISSION HANDLING ====================

   //Check permissions
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            smsPermissionGranted = true;
            smsCheckBox.setChecked(getSmsPreference());
        } else {
            smsPermissionGranted = false;
            smsCheckBox.setChecked(false);
        }
    }

    //Request permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Show explanation if needed
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
                new AlertDialog.Builder(this)
                        .setTitle("SMS Permission Needed")
                        .setMessage("This app needs SMS permission to send you " +
                                "notifications about upcoming events.")
                        .setPositiveButton("OK", (dialog, which) -> {
                            ActivityCompat.requestPermissions(DataGridActivity.this,
                                    new String[]{Manifest.permission.SEND_SMS},
                                    SMS_PERMISSION_CODE);
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            smsCheckBox.setChecked(false);
                        })
                        .show();
            } else {
                // Request permission directly
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            }
        } else {
            // Permission already granted
            smsPermissionGranted = true;
            saveSmsPreference(true);
            Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
        }
    }

    //Handle permissions result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                smsPermissionGranted = true;
                saveSmsPreference(true);
                smsCheckBox.setChecked(true);
                Toast.makeText(this, "SMS notifications enabled",
                        Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied
                smsPermissionGranted = false;
                saveSmsPreference(false);
                smsCheckBox.setChecked(false);
                Toast.makeText(this,
                        "SMS permission denied. App will continue without notifications.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    // ==================== SHARED PREFERENCES ====================

    //Save SMS
    private void saveSmsPreference(boolean enabled) {
        SharedPreferences prefs = getSharedPreferences("AppSettings", MODE_PRIVATE);
        prefs.edit().putBoolean("sms_enabled", enabled).apply();
    }

    //Get SMS status
    private boolean getSmsPreference() {
        SharedPreferences prefs = getSharedPreferences("AppSettings", MODE_PRIVATE);
        return prefs.getBoolean("sms_enabled", false);
    }

    //Get username
    private String getUsernameFromSession() {
        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        return prefs.getString("username", "");
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh events when returning to this activity
        loadEvents();
    }

    private void enableSmsNotifications() {
        // Request SMS permission if not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, 100);
        } else {
            Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
        }
    }

    private void disableSmsNotifications() {
        Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show();
    }
}