package com.example.cs360_project_two;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class EditActivity extends AppCompatActivity {

    private TextView titleView;
    private EditText eventNameEditText;
    private EditText eventDateEditText;
    private Button saveButton;
    private Button backButton;

    private DatabaseHelper databaseHelper;
    private String mode; // "ADD" or "EDIT"
    private int eventId;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize UI components
        titleView = findViewById(R.id.editTitleView);
        eventNameEditText = findViewById(R.id.editTextText);
        eventDateEditText = findViewById(R.id.editTextDate);
        saveButton = findViewById(R.id.saveBtn);
        backButton = findViewById(R.id.backBtn);

        // Get data from intent
        mode = getIntent().getStringExtra("MODE");
        userId = getIntent().getIntExtra("USER_ID", -1);

        // Configure UI based on mode
        if ("EDIT".equals(mode)) {
            setupEditMode();
        } else {
            setupAddMode();
        }

        // Set up button listeners
        setupListeners();
    }

    //Set up UI for existing event
    private void setupEditMode() {
        titleView.setText("Edit Event");
        eventId = getIntent().getIntExtra("EVENT_ID", -1);
        String eventName = getIntent().getStringExtra("EVENT_NAME");
        String eventDate = getIntent().getStringExtra("EVENT_DATE");

        eventNameEditText.setText(eventName);
        eventNameEditText.setHint("");
        eventDateEditText.setText(eventDate);
        eventDateEditText.setHint("");
    }

    //Set up UI for new event
    private void setupAddMode() {
        titleView.setText("Add Event");
        eventNameEditText.setHint("Enter event name");
        eventDateEditText.setHint("MM/DD/YYYY");
    }

    //Set up click listeners
    private void setupListeners() {
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSave();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    //Handles save butting click function
    private void handleSave() {
        String eventName = eventNameEditText.getText().toString().trim();
        String eventDate = eventDateEditText.getText().toString().trim();

        // Validate input
        if (eventName.isEmpty()) {
            Toast.makeText(this, "Please enter an event name",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (eventDate.isEmpty()) {
            Toast.makeText(this, "Please enter an event date",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate date format (basic validation)
        if (!isValidDate(eventDate)) {
            Toast.makeText(this, "Please enter date in MM/DD/YYYY format",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Save based on mode
        boolean success;
        if ("EDIT".equals(mode)) {
            success = databaseHelper.updateEvent(eventId, eventName, eventDate);
            if (success) {
                Toast.makeText(this, "Event updated successfully",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to update event",
                        Toast.LENGTH_SHORT).show();
            }
        } else {
            success = databaseHelper.addEvent(eventName, eventDate, userId);
            if (success) {
                Toast.makeText(this, "Event added successfully",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to add event",
                        Toast.LENGTH_SHORT).show();
            }
        }

        if (success) {
            finish();
        }
    }

    //Input validation for date
    private boolean isValidDate(String date) {
        // Basic regex validation for MM/DD/YYYY format
        String datePattern = "^(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/\\d{4}$";
        return date.matches(datePattern);
    }
}