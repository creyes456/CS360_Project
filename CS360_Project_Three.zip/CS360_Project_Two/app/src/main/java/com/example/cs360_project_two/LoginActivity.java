package com.example.cs360_project_two;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize UI components
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);

        // Set up login button click listener
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLoginOrSignup();
            }
        });
    }

    //Handle login and signup
    private void handleLoginOrSignup() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate input fields
        if (username.isEmpty()) {
            Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Please enter a password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check password length for security
        if (password.length() < 4) {
            Toast.makeText(this, "Password must be at least 4 characters",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if user exists
        if (databaseHelper.checkUsername(username)) {
            // User exists - attempt login
            if (databaseHelper.checkUser(username, password)) {
                // Correct password
                saveUserSession(username);
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                navigateToDataGrid(username);
            } else {
                // Wrong password
                Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show();
            }
        } else {
            // User doesn't exist - create new account automatically
            if (databaseHelper.addUser(username, password)) {
                saveUserSession(username);
                Toast.makeText(this, "Account created and logged in!", Toast.LENGTH_SHORT).show();
                navigateToDataGrid(username);
            } else {
                Toast.makeText(this, "Failed to create account. Please try again.",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Change screens
    private void navigateToDataGrid(String username) {
        Intent intent = new Intent(LoginActivity.this, DataGridActivity.class);
        intent.putExtra("USERNAME", username);
        startActivity(intent);
        finish(); // Close login activity
    }

    //Save user session
    private void saveUserSession(String username) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", username);
        editor.putBoolean("isLoggedIn", true);
        editor.apply();
    }
}