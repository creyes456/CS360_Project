package com.example.cs360_project_two;

public class Event {
    private int eventId;
    private String eventName;
    private String eventDate;
    private int userId;

    //Event class
    public Event(int eventId, String eventName, String eventDate, int userId) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.userId = userId;
    }

    // Getters
    public int getEventId() {
        return eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public String getEventDate() {
        return eventDate;
    }

    public int getUserId() {
        return userId;
    }

    // Setters
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}